"""p99turn: turn-1-mini, an end-of-turn detection model by p99lab.

turn-1-mini is p99lab's own 5.3M-parameter causal streaming model, audio only, for on-device use. It returns
P(the user's turn is over) for the audio heard so far and can be asked at any time during a pause.
Inference only: no training code lives here.
"""
from .audio import SR, agent_context, bandlimit_4k  # noqa: F401

__version__ = "1.2.3"
__all__ = ["Turn1Mini", "Turn1MiniStream", "SR", "bandlimit_4k"]


def __getattr__(name):                      # lazy: importing `p99turn` must not import torch
    if name in ("Turn1Mini", "Turn1MiniStream"):
        from . import mini

        return getattr(mini, name)
    raise AttributeError(name)
