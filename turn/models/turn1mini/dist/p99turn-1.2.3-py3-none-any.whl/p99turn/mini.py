"""turn-1-mini: p99lab's small causal streaming end-of-turn model. Audio only, 5.3M parameters (5.0M trunk + 0.26M head).
Architecture and weights are p99lab's own; no third-party weights are inside or needed at run time.

  input    16 kHz mono, band-limited to 4 kHz (see `p99turn.audio.bandlimit_4k`: REQUIRED, the model was trained on
           telephone-band audio), 80-bin log-mel at a 10 ms hop with causal framing
  trunk    two causal convolutions (20 ms frames), six transformer layers of width 256 with a causal attention window
           of 1.2 s per layer and relative positions (ALiBi): no look-ahead, no dependence on absolute time
  head     MLP on [layer 2, layer 4, layer 6 at the current frame | mean of layer 6 over the frames 1.2 s to 0.2 s back]
  output   P(the user's turn is over) at every 20 ms frame. The benchmarked read-out is any-time: the score can be
           read at any frame of a pause (no fixed score point).

`Turn1Mini.score(prefix)` runs the audio heard so far from a zero state (what the benchmark adapter does).
`Turn1MiniStream` is the chunked version (160 ms steps, cached attention state): same numbers, constant cost per step.
"""
from __future__ import annotations

import math

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from . import names as N
from . import weights as W
from .audio import SR, bandlimit_4k

N_FFT, HOP, N_MELS = 400, 160, 80
CHUNK_MEL = 16                                   # one streaming step = 16 mel frames = 160 ms = 8 output frames
MAX_AUDIO_S = 40.0


def _mel_filterbank(n_mels=N_MELS, n_fft=N_FFT, sr=SR, fmin=20.0, fmax=None):
    fmax = fmax or sr / 2
    hz2mel = lambda f: 2595 * math.log10(1 + f / 700)  # noqa: E731
    mel2hz = lambda m: 700 * (10 ** (m / 2595) - 1)    # noqa: E731
    mels = torch.linspace(hz2mel(fmin), hz2mel(fmax), n_mels + 2)
    hz = torch.tensor([mel2hz(m.item()) for m in mels])
    bins = torch.floor((n_fft + 1) * hz / sr).long()
    fb = torch.zeros(n_mels, n_fft // 2 + 1)
    for i in range(n_mels):
        l, c, r = bins[i].item(), bins[i + 1].item(), bins[i + 2].item()
        for k in range(l, c):
            fb[i, k] = (k - l) / max(1, c - l)
        for k in range(c, r):
            fb[i, k] = (r - k) / max(1, r - c)
    return fb


class LogMel(nn.Module):
    """25 ms window, 10 ms hop, 80 bins. Causal framing: frame t ends at sample (t + 1) * hop."""

    def __init__(self) -> None:
        super().__init__()
        self.register_buffer("window", torch.hann_window(N_FFT), persistent=False)
        self.register_buffer("fb", _mel_filterbank(), persistent=False)

    def forward(self, wav, pad: bool = True):                     # [B, N] float in [-1, 1]
        x = F.pad(wav, (N_FFT - HOP, 0)) if pad else wav          # left pad only
        frames = x.unfold(1, N_FFT, HOP)
        spec = torch.fft.rfft(frames * self.window, dim=-1).abs() ** 2
        m = torch.matmul(spec, self.fb.T).clamp_min(1e-10).log()
        return ((m + 10.0) / 5.0).transpose(1, 2)                 # [B, n_mels, T]


class _CausalConv1d(nn.Conv1d):
    def __init__(self, cin, cout, k, stride=1):
        super().__init__(cin, cout, k, stride=stride)
        self.left = k - 1

    def forward(self, x):
        return super().forward(F.pad(x, (self.left, 0)))


class _Block(nn.Module):
    def __init__(self, d, h, ff):
        super().__init__()
        self.n1, self.n2 = nn.LayerNorm(d), nn.LayerNorm(d)
        self.attn = nn.MultiheadAttention(d, h, batch_first=True)
        self.ff = nn.Sequential(nn.Linear(d, ff), nn.GELU(), nn.Dropout(0.0), nn.Linear(ff, d))

    def forward(self, x, mask):
        y = self.n1(x)
        x = x + self.attn(y, y, y, attn_mask=mask, need_weights=False)[0]
        return x + self.ff(self.n2(x))


class Trunk(nn.Module):
    def __init__(self, d=256, layers=6, heads=4, ff=1024, left_ctx=60):
        super().__init__()
        self.left_ctx, self.heads_n = left_ctx, heads
        self.mel = LogMel()
        self.sub = nn.Sequential(_CausalConv1d(N_MELS, d, 3), nn.GELU(), _CausalConv1d(d, d, 3, stride=2), nn.GELU())
        self.register_buffer("slopes", torch.tensor([2 ** (-8 * (h + 1) / heads) for h in range(heads)]), persistent=False)
        self.blocks = nn.ModuleList([_Block(d, heads, ff) for _ in range(layers)])
        self.norm = nn.LayerNorm(d)

    def forward(self, wav):
        x = self.sub(self.mel(wav)).transpose(1, 2)               # [B, T20, d]
        B, T = x.shape[:2]
        i = torch.arange(T, device=x.device)
        dist = (i[:, None] - i[None, :]).float()
        allowed = (dist >= 0) & (dist < self.left_ctx)
        mask = (-self.slopes[:, None, None] * dist[None]).masked_fill(~allowed[None], float("-inf")).repeat(B, 1, 1).to(x.dtype)
        hs = []
        for b in self.blocks:
            x = b(x, mask)
            hs.append(x)
        hs[-1] = self.norm(hs[-1])
        return hs


def _head():
    return nn.Sequential(nn.LayerNorm(1024), nn.Linear(1024, 256), nn.GELU(), nn.Dropout(0.2), nn.Linear(256, 1))


def _pooled_h6(h6):
    """Mean of layer 6 over frames j-59 .. j-10, zeros before the stream start."""
    x = F.pad(h6.transpose(1, 2), (59, 0))
    return F.avg_pool1d(x, 50, 1)[..., : h6.shape[1]].transpose(1, 2)


class Turn1Mini(nn.Module):
    """weights: local directory / file, or a Hugging Face repo id (default: env P99TURN_WEIGHTS, then `names.REPO_MINI`)."""

    score_point_s = None                       # any-time read-out
    max_audio_s = MAX_AUDIO_S

    def __init__(self, weights=None, *, revision=None, device=None, variant: str = "float32") -> None:
        """variant: "float32" (default), "fp16" or "int8": which file of the same weights to load. The smaller files are
        turned back into float32 at load, so speed and memory in use are the same; only the download is smaller.
        The int8 file is slightly lossy (see the model card)."""
        super().__init__()
        W.gpu_cap()
        tensors, cfg = W.load_safetensors(W.resolve(N.MINI_FILES[variant], weights, revision, N.REPO_MINI))
        self.config = cfg
        self.trunk = Trunk(left_ctx=int(cfg.get("left_ctx", 60)))
        self.head = _head()
        self.load_state_dict(tensors)
        self.to(torch.device(device or "cpu")).eval()

    @property
    def device(self):
        return self.norm_device()

    def norm_device(self):
        return self.trunk.norm.weight.device

    def n_params(self) -> int:
        return sum(p.numel() for p in self.parameters())

    def forward(self, wav):
        """wav [B, N], band-limited -> logits [B, T20], one per 20 ms frame."""
        hs = self.trunk(wav)
        return self.head(torch.cat([hs[1], hs[3], hs[5], _pooled_h6(hs[5])], -1)).squeeze(-1)

    @torch.no_grad()
    def frame_probs(self, audio: np.ndarray, lowpass: bool = True) -> np.ndarray:
        """P(end of turn) at every 20 ms frame of `audio` (16 kHz mono float32), from a zero state."""
        x = np.asarray(audio, np.float32)
        if len(x) < 2 * HOP:
            return np.zeros(0, np.float32)
        if lowpass:
            x = bandlimit_4k(x)
        return torch.sigmoid(self(torch.from_numpy(x).to(self.norm_device())[None])[0].float()).cpu().numpy()

    def score(self, audio: np.ndarray, lowpass: bool = True) -> float:
        """P(end of turn) for the audio heard so far (the last frame's score; at most the last 40 s are used).
        Less than one 20 ms frame of audio -> 0.0 (keep listening)."""
        p = self.frame_probs(np.asarray(audio, np.float32)[-int(MAX_AUDIO_S * SR):], lowpass)
        return float(p[-1]) if len(p) else 0.0

    def stream(self, lowpass: bool = True) -> "Turn1MiniStream":
        return Turn1MiniStream(self, lowpass)


class Turn1MiniStream:
    """Chunked streaming with cached state: push audio of any length, get one probability per finished 20 ms frame.
    Internally steps every 160 ms. Equal to `Turn1Mini.frame_probs` on the same (band-limited) audio up to float error.

    lowpass=True applies the benchmarked low-pass (`p99turn.audio.bandlimit_4k`) causally: at every 160 ms step the
    recent raw audio is filtered again with the audio after "now" counted as zero, which is what scoring a prefix
    offline does. Pass lowpass=False if your audio is already band-limited to 4 kHz."""

    HIST = N_FFT - HOP + 64                                           # raw samples kept: log-mel context + filter support

    def __init__(self, model: Turn1Mini, lowpass: bool = True) -> None:
        self.m, self.use_lp = model, lowpass
        t = model.trunk
        self.L, self.d, self.H, self.W = len(t.blocks), t.norm.normalized_shape[0], t.heads_n, t.left_ctx
        self.dh = self.d // self.H
        self.reset()

    def reset(self) -> None:
        z, dev = torch.zeros, self.m.norm_device()
        self.pending = np.zeros(0, np.float32)                    # samples not yet turned into a 160 ms step
        self.tail = np.zeros(self.HIST if self.use_lp else N_FFT - HOP, np.float32)   # recent input (raw if use_lp): the mel's left context
        self.conv1, self.conv2 = z(1, N_MELS, 2, device=dev), z(1, self.d, 2, device=dev)
        self.k = z(self.L, self.H, self.W, self.dh, device=dev)
        self.v = z(self.L, self.H, self.W, self.dh, device=dev)
        self.k_pos = torch.full((self.W,), -1e9, device=dev)
        self.h6 = z(60, self.d, device=dev)
        self.t0 = 0.0
        self.last = 0.0

    @torch.no_grad()
    def push(self, chunk: np.ndarray) -> np.ndarray:
        self.pending = np.concatenate([self.pending, np.asarray(chunk, np.float32)])
        step, out = CHUNK_MEL * HOP, []
        while len(self.pending) >= step:
            seg, self.pending = self.pending[:step], self.pending[step:]
            win = np.concatenate([self.tail, seg])
            self.tail = win[-len(self.tail):]
            if self.use_lp:
                win = bandlimit_4k(win)[-(N_FFT - HOP + step):]
            wav = torch.from_numpy(win).to(self.m.norm_device())[None]
            out.append(self._step(self.m.trunk.mel(wav, pad=False)))
        p = np.concatenate(out) if out else np.zeros(0, np.float32)
        if len(p):
            self.last = float(p[-1])
        return p

    def score(self) -> float:
        """The most recent frame's P(end of turn)."""
        return self.last

    def _step(self, mel) -> np.ndarray:                           # mel [1, 80, 16]
        t = self.m.trunk
        c1, c2 = t.sub[0], t.sub[2]
        x1 = torch.cat([self.conv1, mel], -1)
        y1 = F.gelu(F.conv1d(x1, c1.weight, c1.bias))
        x2 = torch.cat([self.conv2, y1], -1)
        x = F.gelu(F.conv1d(x2, c2.weight, c2.bias, stride=2)).transpose(1, 2)        # [1, 8, d]
        n = x.shape[1]
        q_pos = self.t0 + torch.arange(n, dtype=torch.float32, device=x.device)
        all_pos = torch.cat([self.k_pos, q_pos])
        dist = q_pos[:, None] - all_pos[None, :]
        allowed = (dist >= 0) & (dist < self.W)
        bias = (-t.slopes[:, None, None] * dist[None]).masked_fill(~allowed[None], float("-inf"))
        new_k, new_v, taps = [], [], []
        for li, blk in enumerate(t.blocks):
            y = blk.n1(x)
            qkv = F.linear(y, blk.attn.in_proj_weight, blk.attn.in_proj_bias).view(1, n, 3, self.H, self.dh)
            q, k, v = (qkv[:, :, j].transpose(1, 2) for j in range(3))
            K, V = torch.cat([self.k[li][None], k], 2), torch.cat([self.v[li][None], v], 2)
            att = (q @ K.transpose(-1, -2)) / math.sqrt(self.dh) + bias[None]
            o = (att.softmax(-1) @ V).transpose(1, 2).reshape(1, n, self.d)
            x = x + blk.attn.out_proj(o)
            x = x + blk.ff(blk.n2(x))
            if li == self.L - 1:
                x = t.norm(x)
            taps.append(x)
            new_k.append(K[0, :, -self.W:])
            new_v.append(V[0, :, -self.W:])
        h2, h4, h6 = taps[1][0], taps[3][0], taps[5][0]
        buf = torch.cat([self.h6, h6], 0)
        pooled = torch.stack([buf[1 + i: 51 + i].mean(0) for i in range(n)])
        p = torch.sigmoid(self.m.head(torch.cat([h2, h4, h6, pooled], -1))).squeeze(-1)
        self.conv1, self.conv2 = x1[..., -2:], x2[..., -2:]
        self.k, self.v, self.k_pos, self.h6, self.t0 = torch.stack(new_k), torch.stack(new_v), all_pos[-self.W:], buf[-60:], self.t0 + n
        return p.float().cpu().numpy()
