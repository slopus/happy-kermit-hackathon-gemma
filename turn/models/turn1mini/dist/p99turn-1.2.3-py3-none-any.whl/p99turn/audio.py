"""Fixed audio preprocessing shared by turn-1 and turn-1-mini. Nothing here is learned."""
from __future__ import annotations

import re

import numpy as np

SR = 16000


def to_mono_16k(array, sampling_rate: int) -> np.ndarray:
    """float32 mono at 16 kHz. Multi-channel input ([N, C]) is averaged; other rates are resampled (polyphase)."""
    x = np.asarray(array, dtype=np.float32)
    if x.ndim > 1:
        x = x.mean(-1)
    if int(sampling_rate) != SR:
        from math import gcd

        from scipy.signal import resample_poly

        g = gcd(int(sampling_rate), SR)
        x = resample_poly(x, SR // g, int(sampling_rate) // g).astype(np.float32)
    return x


def bandlimit_4k(x: np.ndarray) -> np.ndarray:
    """16 kHz -> 8 kHz -> 16 kHz: removes everything above 4 kHz.

    Both models were trained on audio band-limited to 4 kHz, so EVERY input must pass through this (or an equivalent 4 kHz
    low-pass) before the model. Wideband input without it is out of distribution."""
    from scipy.signal import resample_poly

    if len(x) < 64:
        return x.astype(np.float32)
    return resample_poly(resample_poly(x, 1, 2), 2, 1)[: len(x)].astype(np.float32)


def trailing_silence(x: np.ndarray) -> float:
    """Causal estimate of the silence at the end of the window (seconds, 10 ms steps, capped at 3 s).
    A 10 ms frame counts as speech if its level is within 25 dB of the window's loud level (95th percentile)."""
    x = x[-6 * SR:]
    n = len(x) // 160
    if n < 5:
        return 0.0
    db = 10 * np.log10((x[: n * 160].reshape(n, 160) ** 2).mean(1) + 1e-10)
    thr = max(np.percentile(db, 95) - 25.0, -65.0)
    sp = np.nonzero(db > thr)[0]
    return float(min(3.0, (n - 1 - sp[-1]) * 0.01 if len(sp) else n * 0.01))


def silence_features(s) -> np.ndarray:
    s = np.asarray(s, np.float32)
    return np.stack([s, np.minimum(s, 0.3) / 0.3, np.minimum(s, 0.6) / 0.6, np.minimum(s, 1.0), np.log1p(4 * s)], 1)


def norm_text(t: str) -> str:
    return re.sub(r"\s+", " ", re.sub(r"[^\w' ]+", " ", str(t).lower())).strip()


def agent_context(messages) -> str:
    """The agent's previous utterance: the last assistant message of an OpenAI-style message list, lower-cased,
    punctuation removed. Words of the user's current turn are never used."""
    for m in reversed(list(messages or [])):
        if m.get("role") == "assistant":
            return norm_text(m.get("content", ""))
    return ""


class StreamingLowpass:
    """Causal 4 kHz FIR low-pass (state carried between chunks; delay (taps - 1) / 2 samples = 2 ms).
    NOT the filter used for the benchmark numbers, and no longer used by `Turn1MiniStream`: on public dev audio 3 to 7% of
    decisions differ from the benchmarked low-pass (`bandlimit_4k`) with this filter in front. Kept for compatibility."""

    def __init__(self, taps: int = 65) -> None:
        from scipy.signal import firwin

        self.b = firwin(taps, 3800.0, fs=SR).astype(np.float64)
        self.z = np.zeros(taps - 1)

    def __call__(self, chunk: np.ndarray) -> np.ndarray:
        from scipy.signal import lfilter

        y, self.z = lfilter(self.b, [1.0], np.asarray(chunk, np.float64), zi=self.z)
        return y.astype(np.float32)
