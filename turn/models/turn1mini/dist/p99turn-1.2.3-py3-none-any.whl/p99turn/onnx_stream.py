"""turn-1-mini as an ONNX streaming model. Needs only numpy and onnxruntime (no torch).

One step = 160 ms of 16 kHz mono audio (2,560 samples) -> 8 values of P(end of turn), one per 20 ms frame.
The graph carries its own state: 7 tensors that start as zeros and are fed back at every step.
"""
from __future__ import annotations

import numpy as np

STEP = 2560
STATE = ("audio", "conv1", "conv2", "k", "v", "k_valid", "h6")


class Turn1MiniOnnx:
    """path: one of the turn-1-mini.step*.onnx files. threads: CPU threads (1 is enough for a model this small)."""

    def __init__(self, path: str, threads: int = 1) -> None:
        import onnxruntime as ort

        so = ort.SessionOptions()
        so.intra_op_num_threads = so.inter_op_num_threads = threads
        self.sess = ort.InferenceSession(str(path), so, providers=["CPUExecutionProvider"])
        self.shapes = {i.name: tuple(i.shape) for i in self.sess.get_inputs() if i.name.startswith("state_")}
        self.out = ["probs"] + [f"new_state_{s}" for s in STATE]
        self.reset()

    @classmethod
    def from_pretrained(cls, variant: str = "int8", repo: str = "p99lab/turn-1-mini", revision: str | None = None, threads: int = 1):
        """Download a graph from the Hugging Face Hub and open it. variant: "int8" (7.0 MB, fastest) or "float32" (21.8 MB)."""
        from huggingface_hub import hf_hub_download

        name = {"int8": "turn-1-mini.step.int8dyn.onnx", "float32": "turn-1-mini.step.onnx"}[variant]
        try:
            hf_hub_download(repo_id=repo, filename="config.json", revision=revision)
        except Exception:
            pass
        return cls(hf_hub_download(repo_id=repo, filename="onnx/" + name, revision=revision), threads)

    def reset(self) -> None:
        self.state = {n: np.zeros(s, np.float32) for n, s in self.shapes.items()}
        self.pending = np.zeros(0, np.float32)
        self.last = 0.0

    def step(self, audio: np.ndarray) -> np.ndarray:
        """Exactly 2,560 samples -> 8 probabilities."""
        res = self.sess.run(self.out, {"audio": audio.reshape(1, STEP).astype(np.float32), **self.state})
        self.state = {f"state_{s}": r for s, r in zip(STATE, res[1:])}
        self.last = float(res[0][-1])
        return res[0]

    def push(self, chunk: np.ndarray) -> np.ndarray:
        """Audio of any length -> one probability per finished 20 ms frame (empty until 160 ms have arrived)."""
        self.pending = np.concatenate([self.pending, np.asarray(chunk, np.float32)])
        out = []
        while len(self.pending) >= STEP:
            out.append(self.step(self.pending[:STEP]))
            self.pending = self.pending[STEP:]
        return np.concatenate(out) if out else np.zeros(0, np.float32)

    def score(self) -> float:
        """The most recent frame's P(end of turn)."""
        return self.last
