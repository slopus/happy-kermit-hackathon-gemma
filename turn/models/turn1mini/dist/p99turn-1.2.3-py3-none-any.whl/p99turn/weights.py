"""Where the weights come from. Nothing is bundled with the code.

A location is either a local directory / file, or a Hugging Face repo id. Order of precedence:
  1. the `location` argument,  2. the environment variable P99TURN_WEIGHTS,  3. the default repo id (`names.REPO_MINI`).
"""
from __future__ import annotations

import json
import os
from pathlib import Path

from . import names as N

DEFAULT_REVISION = None                              # pin a commit hash here at release time


def resolve(filename: str, location: str | os.PathLike | None = None, revision: str | None = None, default_repo: str = N.REPO_MINI) -> Path:
    loc = str(location or os.environ.get(N.ENV_WEIGHTS) or default_repo)
    p = Path(loc).expanduser()
    if p.is_file():
        return p
    if p.is_dir():
        f = p / filename
        if not f.is_file():
            raise FileNotFoundError(f"{f} not found ({N.ENV_WEIGHTS} / location points at {p})")
        return f
    from huggingface_hub import hf_hub_download

    try:                                              # the repo's config.json is what the Hub counts as a download
        hf_hub_download(repo_id=loc, filename="config.json", revision=revision or DEFAULT_REVISION)
    except Exception:
        pass
    return Path(hf_hub_download(repo_id=loc, filename=filename, revision=revision or DEFAULT_REVISION))


def load_safetensors(path: Path) -> tuple[dict, dict]:
    """-> (float32 tensors, config). The config is the JSON stored under the metadata key `names.METADATA_KEY`.

    Smaller files of the same weights are turned back into float32 here, so the model code never sees the difference:
      float16 file  every tensor is cast to float32
      int8 file     a tensor <name> stored as int8 comes with a float32 tensor <name>.__scale holding one scale per
                    output channel (first dimension): weight = int8 value * scale. Biases and norms are float32."""
    import torch
    from safetensors import safe_open
    from safetensors.torch import load_file

    with safe_open(str(path), framework="pt") as f:
        meta = f.metadata() or {}
    raw, out = load_file(str(path)), {}
    for k, w in raw.items():
        if k.endswith(N.SCALE_SUFFIX):
            continue
        if w.dtype == torch.int8:
            w = w.float() * raw[k + N.SCALE_SUFFIX].view(-1, *[1] * (w.ndim - 1))
        out[k] = w.float()
    return out, json.loads(meta.get(N.METADATA_KEY, "{}"))


def gpu_cap() -> None:
    """Optional: P99TURN_GPU_MEM_GB=<n> limits this process to n GB of GPU memory (shared-memory machines)."""
    gb = os.environ.get("P99TURN_GPU_MEM_GB")
    if gb:
        import torch

        if torch.cuda.is_available():
            total = torch.cuda.get_device_properties(0).total_memory
            torch.cuda.set_per_process_memory_fraction(min(1.0, float(gb) * 2**30 / total), 0)
