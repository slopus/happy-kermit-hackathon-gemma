"""THE one place where public names live."""

ORG = "p99lab"
MINI = "turn-1-mini"                               # 5.3M on-device model: p99lab's own architecture and weights
DISPLAY_MINI = f"{ORG} {MINI}"
REPO_MINI = f"{ORG}/{MINI}"                        # Hugging Face repo id
MINI_FILE = f"{MINI}.safetensors"
MINI_FILES = {"float32": MINI_FILE, "fp16": f"{MINI}.fp16.safetensors", "int8": f"{MINI}.int8.safetensors"}   # same weights, smaller files
SCALE_SUFFIX = ".__scale"                          # int8 files: per-output-channel scale of tensor <name>
ENV_WEIGHTS = "P99TURN_WEIGHTS"                    # local directory (or repo id) overriding the repo above
METADATA_KEY = "p99turn"                           # safetensors metadata key holding the model config
